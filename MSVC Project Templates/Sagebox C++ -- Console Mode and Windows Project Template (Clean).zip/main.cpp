
#include "CSageBox.h"

int main()
{
    CSageBox cSagebox;   
    return 0;
}